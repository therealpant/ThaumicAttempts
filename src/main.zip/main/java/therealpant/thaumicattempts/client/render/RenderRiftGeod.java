package therealpant.thaumicattempts.client.render;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import software.bernie.geckolib3.geo.render.built.GeoModel;
import software.bernie.geckolib3.renderers.geo.GeoBlockRenderer;
import therealpant.thaumicattempts.ThaumicAttempts;
import therealpant.thaumicattempts.client.model.RiftGeodModel;
import therealpant.thaumicattempts.world.block.BlockRiftGeod;
import therealpant.thaumicattempts.world.tile.TileRiftGeod;

@SideOnly(Side.CLIENT)
public class RenderRiftGeod extends GeoBlockRenderer<TileRiftGeod> {

    private EnumFacing lastFacing = EnumFacing.NORTH;

    private static final ResourceLocation TEX_EMISSIVE =
            new ResourceLocation(ThaumicAttempts.MODID, "textures/blocks/rift_geod_e.png");
    private static final float EMISSIVE_Y_OFFSET = 0.01f;

    public RenderRiftGeod() {
        super(new RiftGeodModel());
    }

    private void applyFacingTransform(EnumFacing facing) {
        switch (facing) {
            case DOWN:
                GlStateManager.rotate(180f, 1f, 0f, 0f);
                break;
            case NORTH:
                GlStateManager.rotate(-90f, 1f, 0f, 0f);
                break;
            case SOUTH:
                GlStateManager.rotate(90f, 1f, 0f, 0f);
                break;
            case EAST:
                GlStateManager.rotate(-90f, 0f, 0f, 1f);
                break;
            case WEST:
                GlStateManager.rotate(90f, 0f, 0f, 1f);
                break;
            case UP:
            default:
                break;
        }
    }

    @Override
    public void rotateBlock(EnumFacing facing) {
        this.lastFacing = (facing == null) ? EnumFacing.UP : facing;
        GlStateManager.translate(0.0F, 0.5F, 0.0F);
        applyFacingTransform(this.lastFacing);
        GlStateManager.translate(0.0F, -0.5F, 0.0F);
    }

    private void renderEmissiveLayer(TileRiftGeod te,
                                     double x, double y, double z,
                                     float partialTicks) {
        GeoModel model = this.getGeoModelProvider().getModel(
                this.getGeoModelProvider().getModelLocation(te)
        );

        float[] prevLight = RenderSafety.captureLightmap();

        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(x + 0.5, y + EMISSIVE_Y_OFFSET, z + 0.5);
            rotateBlock(this.lastFacing);
            RenderSafety.setFullBrightLightmap();

            GlStateManager.disableLighting();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(
                    GlStateManager.SourceFactor.SRC_ALPHA,
                    GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                    GlStateManager.SourceFactor.ONE,
                    GlStateManager.DestFactor.ZERO
            );

            Minecraft.getMinecraft().getTextureManager().bindTexture(TEX_EMISSIVE);
            this.render(model, te, partialTicks, 1f, 1f, 1f, 1f);
        } finally {
            GlStateManager.popMatrix();
            RenderSafety.restoreLightmap(prevLight);
            RenderSafety.resetGlState();
        }
    }

    @Override
    public void render(TileRiftGeod te,
                       double x, double y, double z,
                       float partialTicks,
                       int destroyStage,
                       float alpha) {

        if (te == null || te.getWorld() == null) return;

        IBlockState state = te.getWorld().getBlockState(te.getPos());
        if (state.getBlock() instanceof BlockRiftGeod) {
            this.lastFacing = state.getValue(BlockRiftGeod.FACING);
        }

        float[] prevLight = RenderSafety.captureLightmap();
        try {
            super.render(te, x, y, z, partialTicks, destroyStage, alpha);

            if (!RenderSafety.isItemRender()) {
                renderEmissiveLayer(te, x, y, z, partialTicks);
            }
        } finally {
            RenderSafety.restoreLightmap(prevLight);
            RenderSafety.resetGlState();
        }
    }
}