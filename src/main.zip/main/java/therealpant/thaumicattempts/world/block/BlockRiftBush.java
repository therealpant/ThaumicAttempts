package therealpant.thaumicattempts.world.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import thaumcraft.api.blocks.BlocksTC;
import thaumcraft.common.blocks.world.taint.ITaintBlock;
import thaumcraft.common.blocks.world.taint.TaintHelper;
import therealpant.thaumicattempts.ThaumicAttempts;
import therealpant.thaumicattempts.init.ModBlocksItems;
import therealpant.thaumicattempts.util.TADrops;
import therealpant.thaumicattempts.world.EntityFluxAnomalyBurst;
import therealpant.thaumicattempts.world.tile.AnomalyLinkedTile;
import therealpant.thaumicattempts.world.tile.TileRiftBush;

import javax.annotation.Nullable;

/**
 * Высокий куст (2 блока), аналог ванильной розы.
 */
public class BlockRiftBush extends BlockBush implements ITaintBlock {

    public static final PropertyEnum<BlockHalf> HALF = PropertyEnum.create("half", BlockHalf.class);

    public BlockRiftBush() {
        super(Material.VINE);
        setCreativeTab(ThaumicAttempts.CREATIVE_TAB);
        setTranslationKey(ThaumicAttempts.MODID + ".rift_bush");
        setRegistryName(ThaumicAttempts.MODID, "rift_bush");
        setSoundType(SoundType.PLANT);
        setHardness(0.0F);
        setResistance(0.0F);
        setTickRandomly(true);
        setDefaultState(this.blockState.getBaseState().withProperty(HALF, BlockHalf.LOWER));
    }

    @Override
    protected boolean canSustainBush(IBlockState state) {
        return state.getBlock() == Blocks.GRASS
                || state.getBlock() == Blocks.DIRT
                || state.getBlock() == BlocksTC.taintSoil
                || super.canSustainBush(state);
    }

    @Override
    public boolean canPlaceBlockAt(World worldIn, BlockPos pos) {
        return super.canPlaceBlockAt(worldIn, pos) && worldIn.isAirBlock(pos.up());
    }

    @Override
    public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
        worldIn.setBlockState(pos, state.withProperty(HALF, BlockHalf.LOWER), 2);
        worldIn.setBlockState(pos.up(), state.withProperty(HALF, BlockHalf.UPPER), 2);
    }

    @Override
    public void neighborChanged(IBlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos) {
        if (!canBlockStay(worldIn, pos, state)) {
            removeHalf(worldIn, pos, state);
        }
    }

    private void removeHalf(World worldIn, BlockPos pos, IBlockState state) {
        boolean upper = state.getValue(HALF) == BlockHalf.UPPER;
        BlockPos otherPos = upper ? pos.down() : pos.up();
        IBlockState other = worldIn.getBlockState(otherPos);
        if (other.getBlock() == this && other.getValue(HALF) != state.getValue(HALF)) {
            worldIn.setBlockToAir(otherPos);
        }
        worldIn.setBlockToAir(pos);
    }

    public boolean canBlockStay(World worldIn, BlockPos pos, IBlockState state) {
        if (state.getValue(HALF) == BlockHalf.UPPER) {
            IBlockState below = worldIn.getBlockState(pos.down());
            return below.getBlock() == this && below.getValue(HALF) == BlockHalf.LOWER;
        }
        IBlockState above = worldIn.getBlockState(pos.up());
        return above.getBlock() == this && above.getValue(HALF) == BlockHalf.UPPER && super.canPlaceBlockAt(worldIn, pos);
    }

    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        if (state.getValue(HALF) == BlockHalf.LOWER) {
            BlockPos upPos = pos.up();
            IBlockState upState = worldIn.getBlockState(upPos);
            if (upState.getBlock() == this && upState.getValue(HALF) == BlockHalf.UPPER) {
                worldIn.setBlockToAir(upPos);
            }
        }
        super.breakBlock(worldIn, pos, state);
    }

    @Override
    public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
        return false;
    }

    @Override
    public boolean removedByPlayer(IBlockState state, World world, BlockPos pos, EntityPlayer player, boolean willHarvest) {
        if (state.getValue(HALF) == BlockHalf.UPPER) {
            BlockPos downPos = pos.down();
            IBlockState downState = world.getBlockState(downPos);

            if (downState.getBlock() == this && downState.getValue(HALF) == BlockHalf.LOWER) {
                if (player.isCreative()) {
                    world.setBlockToAir(pos);
                    world.setBlockToAir(downPos);
                } else {
                    // ломаем НИЗ, он и даст дроп
                    world.destroyBlock(downPos, true);
                    // верх уже сломан игроком, но чтобы не осталось клиента/серва рассинхрона:
                    world.setBlockToAir(pos);
                }
                return false;
            }
        }
        return super.removedByPlayer(state, world, pos, player, willHarvest);
    }

    @Override
    public Item getItemDropped(IBlockState state, java.util.Random rand, int fortune) {
        return net.minecraft.init.Items.AIR;
    }

    @Override
    public void getDrops(net.minecraft.util.NonNullList<ItemStack> drops,
                         IBlockAccess world,
                         BlockPos pos,
                         IBlockState state,
                         int fortune) {

        drops.clear();

        // верхняя половина не дропает
        if (state.getValue(HALF) == BlockHalf.UPPER) return;

        if (world instanceof World) {
            World w = (World) world;
            TADrops.addRiftDropFixed(drops, w, ModBlocksItems.RIFT_FLOWER);
        }
    }

    @Override
    public ItemStack getItem(World worldIn, BlockPos pos, IBlockState state) {
        return new ItemStack(this);
    }

    @Override
    public ItemStack getPickBlock(IBlockState state, RayTraceResult target, World world, BlockPos pos, EntityPlayer player) {
        return new ItemStack(this);
    }

    @Override
    public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
        return getDefaultState().withProperty(HALF, BlockHalf.LOWER);
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        BlockHalf half = (meta & 1) == 1 ? BlockHalf.UPPER : BlockHalf.LOWER;
        return getDefaultState().withProperty(HALF, half);
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        return state.getValue(HALF) == BlockHalf.UPPER ? 1 : 0;
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, HALF);
    }

    public enum BlockHalf implements IStringSerializable {
        LOWER,
        UPPER;

        @Override
        public String getName() {
            return name().toLowerCase();
        }
    }

    @Override
    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    @Nullable
    @Override
    public net.minecraft.tileentity.TileEntity createTileEntity(World world, IBlockState state) {
        return new TileRiftBush();
    }

    @Override
    public void randomTick(World world, BlockPos pos, IBlockState state, java.util.Random rand) {
        updateTick(world, pos, state, rand);
        if (world.isRemote) return;
        if (world.getBlockState(pos).getBlock() != this) return;

        // Ресурс управляется флюкс-аномалией и не зависит от таинта.
        BlockPos basePos = state.getValue(HALF) == BlockHalf.UPPER ? pos.down() : pos;
        EntityFluxAnomalyBurst anomaly = resolveAnomaly(world, basePos);
        if (anomaly == null || !anomaly.isResourceBlock(this)) {
            return;
        }
        if (state.getValue(HALF) == BlockHalf.UPPER) return;

        if (!anomaly.isResourcesBootstrapped()) return;

        TileRiftBush tile = world.getTileEntity(basePos) instanceof TileRiftBush
                ? (TileRiftBush) world.getTileEntity(basePos)
                : null;
        if (tile == null) return;
        int cooldown = tile.getReproduceCooldown();
        if (cooldown > 0) {
            tile.setReproduceCooldown(cooldown - 1);
            return;
        }
        if (rand.nextInt(6) != 0) return;
        anomaly.requestExtraResource(this);
        tile.setReproduceCooldown(40 + rand.nextInt(80));
    }

    @Override
    public void updateTick(World world, BlockPos pos, IBlockState state, java.util.Random rand) {
        if (world.isRemote) return;
        if (rand.nextInt(10) != 0) return;

        BlockPos basePos = state.getValue(HALF) == BlockHalf.UPPER ? pos.down() : pos;
        if (!TaintHelper.isNearTaintSeed(world, basePos)) {
            die(world, basePos, world.getBlockState(basePos));
        }
    }

    @Override
    public void die(World world, BlockPos pos, IBlockState state) {
        if (world.isRemote) return;

        BlockPos basePos = state.getValue(HALF) == BlockHalf.UPPER ? pos.down() : pos;
        IBlockState base = world.getBlockState(basePos);
        if (base.getBlock() == this) {
            world.setBlockState(basePos, net.minecraft.init.Blocks.DEADBUSH.getDefaultState(), 2);
        }

        IBlockState upper = world.getBlockState(basePos.up());
        if (upper.getBlock() == this) {
            world.setBlockToAir(basePos.up());
        }
    }

    private EntityFluxAnomalyBurst resolveAnomaly(World world, BlockPos pos) {
        net.minecraft.tileentity.TileEntity tile = world.getTileEntity(pos);
        if (!(tile instanceof AnomalyLinkedTile)) {
            return null;
        }
        AnomalyLinkedTile linked = (AnomalyLinkedTile) tile;
        return FluxResourceHelper.findAnomaly(world, linked.getAnomalyId(), linked.getSeedPos());
    }
}