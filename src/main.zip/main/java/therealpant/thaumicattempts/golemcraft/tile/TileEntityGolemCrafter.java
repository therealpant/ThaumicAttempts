package therealpant.thaumicattempts.golemcraft.tile;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.items.ItemStackHandler;
import thaumcraft.api.ThaumcraftApiHelper;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.IEssentiaTransport;
import thaumcraft.api.golems.GolemHelper;
import thaumcraft.api.items.ItemsTC;
import thaumcraft.common.items.ItemTCEssentiaContainer;
import therealpant.thaumicattempts.api.IPatternedWorksite;
import therealpant.thaumicattempts.api.ICloudCraftConsumer;
import therealpant.thaumicattempts.api.IAutomationOrderAcceptor;
import therealpant.thaumicattempts.api.PatternProvisioningSpec;
import therealpant.thaumicattempts.api.PatternRedstoneMode;
import therealpant.thaumicattempts.api.PatternResourceList;
import therealpant.thaumicattempts.golemnet.tile.TileMirrorManager;
import therealpant.thaumicattempts.golemnet.cloud.CloudEndpointRef;
import therealpant.thaumicattempts.golemnet.tile.TilePatternRequester;
import therealpant.thaumicattempts.util.ItemKey;
import therealpant.thaumicattempts.util.ResourceIdentity;
import therealpant.thaumicattempts.golemcraft.item.ItemBasePattern;
import therealpant.thaumicattempts.ThaumicAttempts;

import javax.annotation.Nullable;
import java.util.*;

/**
 * Одноцикловый голем-крафтер:
 * - Редстоун используется ТОЛЬКО для инициации одного цикла (по фронту 0→1).
 * - Цикл: пошаговые заявки ресурсов → один выпуск → завершение.
 * - Следующий цикл стартует только по следующему фронту 0→1.
 - Стоимость эссенции: 2 * число уникальных типов входов. Эссенция: CRAFT, приём снизу/с боков.
 */
public class TileEntityGolemCrafter extends TileEntity implements ITickable, IEssentiaTransport, IPatternedWorksite, ICloudCraftConsumer {

    // ===== Константы =====
    public static final int PATTERN_SLOTS = 15;
    public static final int INPUT_SLOTS   = 18;
    private static final int OUTPUT_SLOTS = 9;
    // как часто перезаказываем тот же шаг, если не принесли
    private static final long REORDER_TICKS   = 10L;
    private static final int  SUPPLY_COOLDOWN = 0;

    private static final PatternProvisioningSpec PROVISION_SPEC = PatternProvisioningSpec.crafterSpec(SUPPLY_COOLDOWN);

    private static final String NBT_PATTERNS   = "PatternInv";
    private static final String NBT_INPUT      = "InputInv";
    private static final String NBT_OUTPUT     = "OutputInv";
    private static final String NBT_CUSTOMNAME = "CustomName";
    private static final String TAG_RESULT = "Result";
    private static final String TAG_GRID   = "Grid";
    private static final EnumFacing[] ESSENTIA_INPUT_FACES = {
            EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.EAST
    };

    private static final int  CRAFT_CAP       = 128;
    private static final int  CRAFT_SUCTION   = 128;

    private int lastSignal = 0; // 0..15, чтобы ловить фронт 0->N

    // Привязка к менеджеру (через PatternRequester сверху)
    private @Nullable BlockPos managerPos = null;
    private boolean managerFromPattern = false;
    private boolean needEnsureWithManager = false;
    private long lastEnsureWorldTime = -9999L;

    // Очередь запусков от реквестера (индексы паттернов, 0-based)
    private final java.util.Deque<Integer> requesterQueue = new java.util.ArrayDeque<>();
    // Флаг: текущая работа запущена от реквестера (чтобы подавить самопровизию)
    private boolean jobViaRequester = false;
    private final LinkedHashSet<UUID> cloudTaskIds = new LinkedHashSet<>();

    private void cloudDebug(String msg, Object... args) {
        String fmt = msg == null ? "" : msg.replace("{}", "%s");
        ThaumicAttempts.LOGGER.debug("[GolemCraftConsumer " + pos + "] " + String.format(fmt, args));
    }
    // ===== Состояние / параметры =====
    private String customName = "";

    /** Тип эссенции — оставляем CRAFT; наследники могут заменить. */
    protected Aspect requiredAspect = Aspect.CRAFT;
    /** Сколько эссенции тратим за каждый ВИД ресурса. */
    protected int perTypeEssentia = 1;

    /** Буфер эссенции. */
    private int craftAmount = 0;
    private int costRemaining = 0;

    /** Активен ли единичный цикл. */
    private boolean jobActive = false;
    private int jobRepeatLeft = 1;
    private int jobRepeatTotal = 1;

    /** Какой слот-паттерн выбрали при старте цикла. */
    int jobPatternIndex = -1;

    /** Список шагов: ключ (count=1) → сколько штук нужно. */
    protected final List<Req> seq = new ArrayList<>();
    protected int step = 0;
    private long lastOrderWorldTime = 0;
    private int supplyCooldown = 0;
    private int suctionPingCooldown = 0;
    private int drawDelay = 0;

    private boolean suppressSelfProvision = false;
    public void setSuppressSelfProvision(boolean v){ suppressSelfProvision = v; }

    // ===== Инвентари =====
    protected final ItemStackHandler patterns = new ItemStackHandler(PATTERN_SLOTS) {
        @Override public boolean isItemValid(int slot, ItemStack stack) {
            return stack != null && !stack.isEmpty()
                    && stack.getItem() instanceof therealpant.thaumicattempts.golemcraft.item.ItemBasePattern;
        }
        @Override protected void onContentsChanged(int slot) { markDirty(); }
    };

    private final ItemStackHandler input   = new ItemStackHandler(INPUT_SLOTS) {
        @Override protected void onContentsChanged(int slot) { markDirty(); }
    };

    @Override
    public net.minecraftforge.items.IItemHandler getPatternHandler(){ return patterns; }
    public net.minecraftforge.items.IItemHandler getInputHandler() { return input; }
    public net.minecraftforge.items.IItemHandler getOutputHandler(){ return output; }

    protected int getFuel() { return this.craftAmount; }
    protected void consumeFuel(int amt) { this.craftAmount = Math.max(0, this.craftAmount - Math.max(0, amt)); markDirty(); }

    // ===== Utility: кристаллы / матчинг =====
    private static boolean isTcCrystal(ItemStack s) {
        return s != null && !s.isEmpty() && s.getItem() == ItemsTC.crystalEssence;
    }
    @Nullable
    private static Aspect crystalAspect(ItemStack s) {
        if (!isTcCrystal(s)) return null;
        thaumcraft.api.aspects.AspectList al = ((ItemTCEssentiaContainer) ItemsTC.crystalEssence).getAspects(s);
        if (al != null && al.size() == 1) return al.getAspects()[0];
        return null;
    }

    /** Универсальный матчинг для «входов сетки» и списаний:
     *  - кристаллы — строго по аспекту
     *  - нестакуемые — item + meta
     *  - стакаемые — relaxed
     */
    private static boolean sameForGrid(ItemStack a, ItemStack b) {
        return ResourceIdentity.sameResource(a, b);
    }

    private ItemStackHandler output = makeOutputHandler(OUTPUT_SLOTS);

    private ItemStackHandler makeOutputHandler(int size) {
        return new ItemStackHandler(size) {
            @Override protected void onContentsChanged(int slot) { markDirty(); }
        };
    }

    private static ItemStack key1ForGrid(ItemStack s) {
        return PatternResourceList.normalizeForKey(s);
    }

    // ===== Привязки =====
    public int findPatternIndexForResultLike(ItemStack like1) {
        if (like1 == null || like1.isEmpty()) return -1;
        if (patterns == null) return -1;

        final int slots = patterns.getSlots();
        for (int i = 0; i < slots; i++) {
            ItemStack pat = patterns.getStackInSlot(i);
            if (pat == null || pat.isEmpty()) continue;

            NonNullList<ItemStack> grid = getGrid(pat);
            ItemStack preview = getCraftPreview(pat, grid);
            if (preview.isEmpty()) continue;

            // ВАЖНО: используем ту же семантику, что и для входов/у реквестера
            if (sameForGrid(preview, like1)) {
                return i;
            }
        }
        return -1;
    }

    /** Поставить в очередь N запусков по индексу паттерна (0-based). Возвращает, сколько реально добавили. */
    public int enqueueCraftsByRequesterIndex(int patternIndex, int times) {
        if (patternIndex < 0 || patternIndex >= PATTERN_SLOTS) return 0;
        if (!patternIndexValid(patternIndex)) return 0;
        int n = Math.max(1, times);
        for (int i = 0; i < n; i++) requesterQueue.addFirst(patternIndex);

        // В режиме редстоун-заказа с менеджером может возникать дедлок:
        // активный «ручной» цикл ждёт промежуточку, а промежуточный цикл
        // уже поставлен менеджером в requesterQueue, но не стартует пока jobActive=true.
        // В таком случае мягко прерываем текущий цикл и переносим его в хвост очереди,
        // чтобы сначала выполнить промежуточный requester-заказ.
        if (shouldPreemptForRequesterQueue()) {
            pauseActiveJobIntoRequesterQueueTail();
            tryStartNextRequesterJob();
        }

        markDirty();
        return n;
    }

    public void dropContents() {
        if (world == null || world.isRemote) return;

        dropHandler(patterns);
        dropHandler(input);
        dropHandler(output);
    }

    private void dropHandler(ItemStackHandler handler) {
        if (handler == null) return;
        for (int i = 0; i < handler.getSlots(); i++) {
            ItemStack stack = handler.getStackInSlot(i);
            if (!stack.isEmpty()) {
                net.minecraft.inventory.InventoryHelper.spawnItemStack(world, pos.getX(), pos.getY(), pos.getZ(), stack.copy());
                handler.setStackInSlot(i, ItemStack.EMPTY);
            }
        }
    }

    /** Поставить в очередь N запусков по "результату как этот". Удобно, если реквестер знает только like1. */
    public int enqueueCraftsByRequesterLike(ItemStack like1, int times) {
        if (like1 == null || like1.isEmpty()) return 0;
        int idx = findPatternIndexForResultLike(like1);
        return (idx < 0) ? 0 : enqueueCraftsByRequesterIndex(idx, times);
    }

    public boolean hasRequesterQueue() {
        return !requesterQueue.isEmpty() || (jobViaRequester && jobActive);
    }

    @Override
    public int enqueueFromPatternRequester(int patternSlot, int times) {
        return enqueueCraftsByRequesterIndex(patternSlot, times);
    }

    @Override
    public int enqueueFromPatternRequester(ItemStack resultLike, int times) {
        return enqueueCraftsByRequesterLike(resultLike, times);
    }

    @Override
    public List<ItemStack> listCraftableResults() {
        ArrayList<ItemStack> out = new ArrayList<>();
        for (int i = 0; i < patterns.getSlots(); i++) {
            ItemStack pat = patterns.getStackInSlot(i);
            if (pat == null || pat.isEmpty() || !(pat.getItem() instanceof ItemBasePattern)) continue;
            ItemStack preview = getCraftPreview(pat, getGrid(pat));
            if (preview.isEmpty()) continue;
            ItemStack one = preview.copy();
            one.setCount(Math.max(1, one.getCount()));
            out.add(one);
        }
        return out;
    }

    @Override
    public int getPerCraftOutputCountFor(ItemStack like) {
        if (like == null || like.isEmpty()) return 0;
        int idx = findPatternIndexForResultLike(like);
        if (idx < 0) return 0;
        ItemStack pat = patterns.getStackInSlot(idx);
        if (pat.isEmpty()) return 0;
        ItemStack preview = getCraftPreview(pat, getGrid(pat));
        return preview.isEmpty() ? 0 : Math.max(1, preview.getCount());
    }

    @Override
    public void enqueueCraft(ItemStack resultLike, int crafts) {
        enqueueCloudCraft(resultLike, crafts, UUID.randomUUID());
    }

    @Override
    public boolean hasActiveOrQueued() {
        return jobActive || !requesterQueue.isEmpty();
    }

    @Override
    public Map<ItemKey, Integer> getInputsPerCycle(ItemStack resultLike) {
        LinkedHashMap<ItemKey, Integer> out = new LinkedHashMap<>();
        int idx = findPatternIndexForResultLike(resultLike);
        if (idx < 0) return out;
        ItemStack pat = patterns.getStackInSlot(idx);
        NonNullList<ItemStack> grid = getGrid(pat);
        for (int i = 0; i < 9; i++) {
            ItemStack in = grid.get(i);
            if (in == null || in.isEmpty()) continue;
            ItemKey key = ItemKey.of(key1ForGrid(in));
            if (key == null || key == ItemKey.EMPTY) continue;
            out.merge(key, Math.max(1, in.getCount()), Integer::sum);
        }
        if (!out.isEmpty()) cloudDebug("publish recipe result={} inputs={}", resultLike, out);
        return out;
    }

    @Override
    public int enqueueCloudCraft(ItemStack resultLike, int cycles, UUID taskId) {
        if (taskId == null) return 0;
        int accepted = enqueueCraftsByRequesterLike(resultLike, cycles);
        if (accepted > 0) {
            cloudTaskIds.add(taskId);
            cloudDebug("accepted cloud craft task id={} result={} cycles={}", taskId, resultLike, accepted);
        }
        return accepted;
    }

    @Override
    public boolean hasCloudCraftTask(UUID taskId) {
        if (taskId == null || !cloudTaskIds.contains(taskId)) return false;
        if (!hasActiveOrQueued()) {
            cloudTaskIds.remove(taskId);
            cloudDebug("task done id={}", taskId);
            return false;
        }
        return true;
    }

    @Override
    public int getOutputCount(ItemKey key) {
        if (key == null || key == ItemKey.EMPTY) return 0;
        ItemStack like = key.toStack(1);
        if (like.isEmpty()) return 0;
        int total = 0;
        for (int i = 0; i < output.getSlots(); i++) {
            ItemStack st = output.getStackInSlot(i);
            if (!st.isEmpty() && ResourceIdentity.sameResource(st, like)) total += st.getCount();
        }
        return total;
    }

    @Override
    public CloudEndpointRef getInputEndpoint() {
        return new CloudEndpointRef(pos, EnumFacing.UP.getIndex());
    }

    @Override
    public CloudEndpointRef getOutputEndpoint() {
        return new CloudEndpointRef(pos, EnumFacing.DOWN.getIndex());
    }

    private void tryStartNextRequesterJob() {
        if (jobActive) return;
        Integer next = requesterQueue.pollFirst();
        if (next == null) return;
        if (!patternIndexValid(next)) return;

        this.suppressSelfProvision = true; // от реквестера — без заявок снабжения
        this.jobViaRequester = true;
        startOneCraftCycle(next);
    }


    // ===== Внутренние типы =====
    static final class Req {
        final ItemStack key1; // ключ (count=1)
        final int count;
        Req(ItemStack key1, int count) { this.key1 = key1; this.count = Math.max(1, count); }
    }

    // ===== Capability =====
    @Override
    public boolean hasCapability(net.minecraftforge.common.capabilities.Capability<?> capability, EnumFacing facing) {
        if (capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) return true;
        return super.hasCapability(capability, facing);
    }
    @SuppressWarnings("unchecked")
    @Override
    public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> capability, EnumFacing facing) {
        if (capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return (T) (facing == EnumFacing.DOWN ? output : input);
        }
        return super.getCapability(capability, facing);
    }

    // ===== Редстоун ===== //
    private int readSignal() {
        if (world == null) return 0;

        int signal = 0;

        // слабый сигнал со всех сторон (в т.ч. от проводов)
        for (EnumFacing f : EnumFacing.VALUES) {
            signal = Math.max(signal, world.getRedstonePower(pos, f));
        }

        // сильный сигнал блока-питателя (рычаги/факелы/компараторы вплотную)
        signal = Math.max(signal, world.getStrongPower(pos));

        // ВАЖНО: НЕ использовать world.isBlockPowered(pos) -> это только boolean,
        // который нельзя "апгрейдить" до 15, иначе любой сигнал станет 15.
        if (signal < 0) signal = 0;
        if (signal > 15) signal = 15;

        return signal;
    }

    /** Перевод силы сигнала в индекс паттерна: 1→0, 2→1, ... */
    private int patternIndexFromSignal(int signal) {
        if (signal <= 0) return -1;
        return Math.min(signal - 1, PATTERN_SLOTS - 1);
    }

    // ===== Паттерн/сетка =====
    private NonNullList<ItemStack> getGrid(ItemStack pattern) {
        NonNullList<ItemStack> grid = NonNullList.withSize(9, ItemStack.EMPTY);
        if (pattern == null || pattern.isEmpty()) return grid;
        NBTTagCompound tag = pattern.getTagCompound();
        if (tag == null || !tag.hasKey(TAG_GRID, Constants.NBT.TAG_LIST)) return grid;
        NBTTagList list = tag.getTagList(TAG_GRID, Constants.NBT.TAG_COMPOUND);
        int max = Math.min(list.tagCount(), 9);
        for (int i = 0; i < max; i++) {
            ItemStack s = new ItemStack(list.getCompoundTagAt(i));
            grid.set(i, s == null ? ItemStack.EMPTY : s);
        }
        return grid;
    }

    protected void rebuildSequence(ItemStack pattern, NonNullList<ItemStack> grid) {
        seq.clear();

        List<PatternResourceList.Entry> resources = PatternResourceList.build(pattern);
        if ((resources == null || resources.isEmpty()) && grid != null) {
            resources = PatternResourceList.aggregate(grid, false);
        }

        if (resources != null) {
            for (PatternResourceList.Entry e : resources) {
                if (e == null) continue;
                ItemStack key = e.getKeyStack();
                if (key == null || key.isEmpty()) continue;
                seq.add(new Req(key, e.getCount()));
            }
        }
        step = 0;
    }

    // ===== Подсчёты/списание =====
    protected int countInInput(ItemStack key1) {
        int have = 0;
        for (int i = 0; i < input.getSlots(); i++) {
            ItemStack s = input.getStackInSlot(i);
            if (!s.isEmpty() && sameForGrid(s, key1)) have += s.getCount();
        }
        return have;
    }

    protected boolean hasAllForGrid(NonNullList<ItemStack> grid) {
        ItemStack pat = (this.jobPatternIndex >= 0 && this.jobPatternIndex < PATTERN_SLOTS)
                ? this.patterns.getStackInSlot(this.jobPatternIndex) : ItemStack.EMPTY;

        List<PatternResourceList.Entry> need = PatternResourceList.build(pat);
        if ((need == null || need.isEmpty()) && grid != null) {
            need = PatternResourceList.aggregate(grid, false);
        }
        if (need == null || need.isEmpty()) return false;
        for (PatternResourceList.Entry entry : need) {
            if (entry == null) continue;
            ItemStack key = entry.getKeyStack();
            if (key == null || key.isEmpty()) continue;
            if (countInInput(key) < entry.getCount()) return false;
        }
        return true;
    }

    protected void consumeForGrid(NonNullList<ItemStack> grid) {
        ItemStack pat = (this.jobPatternIndex >= 0 && this.jobPatternIndex < PATTERN_SLOTS)
                ? this.patterns.getStackInSlot(this.jobPatternIndex) : ItemStack.EMPTY;
        List<PatternResourceList.Entry> need = PatternResourceList.build(pat);
        if ((need == null || need.isEmpty()) && grid != null) {
            need = PatternResourceList.aggregate(grid, false);
        }
        if (need == null || need.isEmpty()) return;

        for (PatternResourceList.Entry entry : need) {
            if (entry == null) continue;
            int left = entry.getCount();
            ItemStack key = entry.getKeyStack();
            if (key == null || key.isEmpty()) continue;
            for (int i = 0; i < input.getSlots() && left > 0; i++) {
                ItemStack have = input.getStackInSlot(i);
                if (have.isEmpty()) continue;
                if (sameForGrid(have, key)) {
                    int take = Math.min(left, have.getCount());
                    ItemStack ns = have.copy(); ns.shrink(take);
                    input.setStackInSlot(i, ns);
                    left -= take;
                }
            }
        }
    }

    // ===== Превью/стоимость =====
    private ItemStack getStoredPreview(ItemStack pattern) {
        if (pattern == null || pattern.isEmpty()) return ItemStack.EMPTY;
        // Аркан-шаблон — доверяем его превью
        if (pattern.getItem() instanceof therealpant.thaumicattempts.golemcraft.item.ItemArcanePattern) {
            ItemStack arc = therealpant.thaumicattempts.golemcraft.item.ItemArcanePattern
                    .calcArcaneResultPreview(pattern, world);
            if (arc != null && !arc.isEmpty()) return arc.copy();
        }
        // Обычный — только TAG_RESULT
        NBTTagCompound tag = pattern.getTagCompound();
        if (tag != null && tag.hasKey(TAG_RESULT, Constants.NBT.TAG_COMPOUND)) {
            ItemStack res = new ItemStack(tag.getCompoundTag(TAG_RESULT));
            if (!res.isEmpty()) return res;
        }
        return ItemStack.EMPTY;
    }

    /** Единая точка получения превью результата:
     *  1) сначала читаем из NBT (TAG_RESULT),
     *  2) если нет — вычисляем ванильный 3×3 через CraftingManager.
     */
    protected ItemStack getCraftPreview(ItemStack pattern, NonNullList<ItemStack> grid) {
        // 1) из NBT
        ItemStack cached = getStoredPreview(pattern);
        if (!cached.isEmpty()) return cached;

        // 2) расчет ванильного 3×3
        if (grid == null) return ItemStack.EMPTY;
        InventoryCrafting inv = new InventoryCrafting(new Container() {
            @Override public boolean canInteractWith(EntityPlayer p) { return false; }
        }, 3, 3);
        for (int i = 0; i < 9; i++) inv.setInventorySlotContents(i, grid.get(i).copy());
        ItemStack direct = CraftingManager.findMatchingResult(inv, world);
        return (direct == null || direct.isEmpty()) ? ItemStack.EMPTY : direct.copy();
    }

    private int getPatternRepeatCount(ItemStack pattern) {
        if (pattern == null || pattern.isEmpty()) return 1;
        if (pattern.getItem() instanceof ItemBasePattern) {
            return ItemBasePattern.getRepeatCount(pattern);
        }
        return 1;
    }

    private int distinctTypes(NonNullList<ItemStack> grid) {
        List<ItemStack> uniq = new ArrayList<>();
        for (ItemStack s : grid) {
            if (s.isEmpty()) continue;
            ItemStack k1 = key1ForGrid(s);
            if (k1.isEmpty()) continue;
            boolean seen = false;
            for (ItemStack u : uniq) { if (sameForGrid(u, k1)) { seen = true; break; } }
            if (!seen) uniq.add(k1);
        }
        return uniq.size();
    }

    protected int getPerCraftCost(ItemStack pattern, NonNullList<ItemStack> grid) {
        return Math.max(1, perTypeEssentia) * Math.max(0, distinctTypes(grid));
    }

    // ===== Эссенция =====
    private boolean drawEssentiaTicked() {
        if (++drawDelay % 5 != 0 || world == null || world.isRemote) return false;
        if (craftAmount >= CRAFT_CAP) return false;
        boolean pulled = false;
        for (EnumFacing inFace : ESSENTIA_INPUT_FACES) {
            TileEntity te = ThaumcraftApiHelper.getConnectableTile(world, pos, inFace);
            if (!(te instanceof IEssentiaTransport)) continue;
            IEssentiaTransport ic = (IEssentiaTransport) te;
            EnumFacing opp = inFace.getOpposite();
            if (!ic.canOutputTo(opp)) continue;
            if (ic.getSuctionAmount(opp) < this.getSuctionAmount(inFace)) {
                int taken = ic.takeEssentia(requiredAspect, 1, opp);
                if (taken > 0) {
                    craftAmount = Math.min(CRAFT_CAP, craftAmount + taken);
                    pulled = true;
                    break;
                }
            }
        }
        if (pulled) { markDirty(); pingNeighbors(); }
        return pulled;
    }

    /** Пытается списать до amt единиц эссенции. Возвращает true, если чанк оплачен полностью. */
    private boolean tryPayEssentiaChunk(int amt) {
        if (amt <= 0) return true;
        if (craftAmount <= 0) return false;
        int take = Math.min(amt, craftAmount);
        craftAmount -= take;
        costRemaining = Math.max(0, costRemaining - take);
        markDirty(); pingNeighbors();
        return take >= amt;
    }


    // ===== Выход =====
    private boolean canAcceptResult(ItemStack result) {
        if (result == null || result.isEmpty()) return false;
        ItemStack left = result.copy();
        // симуляцией проверяем, что ВСЯ стопка влезет в output (в любую комбинацию слотов)
        for (int i = 0; i < output.getSlots(); i++) {
            left = output.insertItem(i, left, true); // simulate = true
            if (left.isEmpty()) return true;
        }
        return false;
    }
    private void pushResult(ItemStack result) {
        if (result == null || result.isEmpty()) return;
        cloudDebug("output appeared result=%s", result);
        ItemStack left = result.copy();
        for (int i = 0; i < output.getSlots(); i++) {
            left = output.insertItem(i, left, false); // реальная вставка
            if (left.isEmpty()) return;
        }
    }

    /** Выбор индекса паттерна по сигналу, с фолбэком на первый валидный. */
    private int choosePatternIndexForSignal(int signal) {
        int idx = patternIndexFromSignal(signal); // 1->0, 2->1, ...
        if (patternIndexValid(idx)) return idx;
        for (int i = 0; i < PATTERN_SLOTS; i++) if (patternIndexValid(i)) return i;
        return -1;
    }

    private boolean hasPatternRequesterAbove() {
        if (world == null) return false;
        TileEntity te = world.getTileEntity(pos.up());
        return te instanceof TilePatternRequester;
    }

    private boolean useManagerForProvision() {
        return hasPatternRequesterAbove() && managerPos != null;
    }

    private void syncManagerFromPattern() {
        if (world == null || world.isRemote) return;

        TileEntity above = world.getTileEntity(pos.up());
        if (above instanceof TilePatternRequester) {
            TilePatternRequester requester = (TilePatternRequester) above;
            BlockPos patternManager = requester.getManagerPos();
            if (patternManager != null) {
                setManagerPos(patternManager, true);
            } else if (managerFromPattern) {
                setManagerPos(null, false);
            }
        } else if (managerFromPattern) {
            setManagerPos(null, false);
        }
    }

    private void setManagerPos(@Nullable BlockPos pos, boolean fromPattern) {
        BlockPos newPos = pos == null ? null : pos.toImmutable();
        boolean newFlag = fromPattern && newPos != null;
        if (!Objects.equals(this.managerPos, newPos) || this.managerFromPattern != newFlag) {
            this.managerPos = newPos;
            this.managerFromPattern = newFlag;
            this.needEnsureWithManager = needEnsureWithManager || useManagerForProvision();
            markDirty();
        }
    }

    public void setManagerPos(@Nullable BlockPos pos) {
        setManagerPos(pos, false);
    }

    public @Nullable BlockPos getManagerPos() { return managerPos; }

    @Override
    public void setManagerPosFromPattern(@Nullable BlockPos managerPos) {
        setManagerPos(managerPos, true);
    }

    @Override
    public @Nullable BlockPos getManagerPosForPattern() {
        return getManagerPos();
    }

    @Override
    public PatternRedstoneMode getRedstoneMode() {
        return PatternRedstoneMode.RISING_EDGE_SELECTS_SLOT;
    }

    @Override
    public PatternProvisioningSpec getProvisioningSpec() {
        return PROVISION_SPEC;
    }

    public void clearManagerPosFromManager(BlockPos pos) {
        if (pos != null && pos.equals(this.managerPos)) {
            setManagerPos(null);
        }
    }

    private Map<ItemKey, Integer> collectMissingForJob() {
        Map<ItemKey, Integer> miss = new LinkedHashMap<>();
        if (seq.isEmpty()) return miss;

        int repeats = Math.max(1, jobRepeatLeft);

        for (Req r : seq) {
            if (r == null || r.key1 == null || r.key1.isEmpty()) continue;
            int need = Math.max(0, r.count * repeats - countInInput(r.key1));
            if (need > 0) {
                ItemKey k = ItemKey.of(r.key1);
                if (k != null) miss.merge(k, need, Integer::sum);
            }
        }
        return miss;
    }

    private void ensureWithManager(boolean force) {
        if (!useManagerForProvision() || world == null || managerPos == null || !jobActive) return;

        long now = world.getTotalWorldTime();
        if (!force && !needEnsureWithManager && now - lastEnsureWorldTime < 5L) return;

        Map<ItemKey, Integer> miss = collectMissingForJob();
        if (miss.isEmpty()) {
            needEnsureWithManager = false;
            return;
        }

        TileEntity te = world.getTileEntity(managerPos);
        if (te instanceof TileMirrorManager) {
            therealpant.thaumicattempts.golemnet.tile.CloudOrderSubmitHelper.submitBatchDelivery(
                    world,
                    ((TileMirrorManager) te).getPos(),
                    this.pos,
                    -1,
                    new java.util.ArrayList<>(miss.entrySet())
            );
            lastEnsureWorldTime = now;
            needEnsureWithManager = false;
        } else {
            needEnsureWithManager = true; // попробуем позже
        }
    }

    // ===== Tick =====
    @Override
    public void onLoad() {
        super.onLoad();
        if (world != null && !world.isRemote) {
            this.lastSignal = readSignal(); // синхронизация, чтобы не стартовать случайно
            syncManagerFromPattern();
        }
    }


    @Override
    public void update() {
        if (world == null) return;

        if (!world.isRemote) {
            syncManagerFromPattern();
        }

        if (world.isRemote) return;

        if (supplyCooldown > 0) supplyCooldown--;
        drawEssentiaTicked();
        if (suctionPingCooldown-- <= 0) {
            if (craftAmount < CRAFT_CAP) pingNeighbors();
            suctionPingCooldown = 20;
        }

        if (jobActive && useManagerForProvision()) {
            ensureWithManager(false);
        }

        // СНАЧАЛА пробуем запустить из очереди реквестера
        int signal = readSignal();

        // 1) если есть очередь от реквестера — запускаем её первой
        if (!jobActive && !requesterQueue.isEmpty()) {
            tryStartNextRequesterJob();
        }

        // Триггер по редстоуну работает только в standalone-режиме.
        // Если крафтер подключён к MirrorManager (через PatternRequester сверху),
        // redstone-заказы отключены: крафт запускается только через manager/терминал.
        if (!useManagerForProvision() && lastSignal == 0 && signal > 0) {
            TileEntity above = world.getTileEntity(pos.up());
            if (above instanceof IAutomationOrderAcceptor) {
                int idx = choosePatternIndexForSignal(signal);
                if (idx >= 0) {
                    ItemStack pat = patterns.getStackInSlot(idx);
                    int repeats = Math.max(1, getPatternRepeatCount(pat));
                    BlockPos manager = (above instanceof TilePatternRequester)
                            ? ((TilePatternRequester) above).getManagerPos()
                            : null;
                    ((IAutomationOrderAcceptor) above).submitAutomationOrder(idx, repeats, manager, null, -1);
                }
            }
        }

        if (jobActive) runActiveJob();

        lastSignal = signal;
    }


    protected void startOneCraftCycle(int idx, int repeats) {

        this.costRemaining = 0; // посчитаем при первом тике, когда будет grid

        jobActive = true;
        jobPatternIndex = idx;
        jobRepeatTotal = Math.max(1, repeats);
        jobRepeatLeft = jobRepeatTotal;

        seq.clear();
        step = 0;

        long now = (world != null) ? world.getTotalWorldTime() : 0L;
        lastOrderWorldTime = now - REORDER_TICKS;
        supplyCooldown = 0;

        needEnsureWithManager = useManagerForProvision();
        if (needEnsureWithManager) {
            lastEnsureWorldTime = now - 5L;
        }

        markDirty();
        cloudDebug("task start pattern={} cycles={}", idx, repeats);
    }

    protected void startOneCraftCycle(int idx) {
        startOneCraftCycle(idx, 1);
    }


    private boolean patternIndexValid(int idx) {
        if (idx < 0 || idx >= PATTERN_SLOTS) return false;
        ItemStack pat = patterns.getStackInSlot(idx);
        if (pat.isEmpty()) return false;
        NonNullList<ItemStack> grid = getGrid(pat);
        ItemStack preview = getCraftPreview(pat, grid); // ← обязательно так
        return !preview.isEmpty();
    }

    private void runActiveJob() {
        if (!jobActive) return;

        if (jobPatternIndex < 0 || jobPatternIndex >= PATTERN_SLOTS) { finishJob(); return; }
        ItemStack pat = patterns.getStackInSlot(jobPatternIndex);
        if (pat.isEmpty()) { finishJob(); return; }

        NonNullList<ItemStack> grid = getGrid(pat);

        // Собираем последовательность (типы) при первом заходе
        if (seq.isEmpty()) rebuildSequence(pat, grid);

        // Предпросмотр результата обязателен
        ItemStack preview = getCraftPreview(pat, grid);
        if (preview.isEmpty()) { finishJob(); return; }

        // Посчитаем общий долг по эссенции один раз в начале цикла
        if (costRemaining <= 0) {
            costRemaining = getPerCraftCost(pat, grid);
        }

        // Если входы уже приехали полностью — сразу к финальной фазе (но долг оплачиваем всё равно частями)
        if (collectMissingForJob().isEmpty()) {
            step = seq.size();
        }

        // --- Снабжение/оплата по типам по очереди ---
        if (step < seq.size()) {
            Req r = seq.get(step);

            // Есть ли достаточно входов для текущего типа?
            int have = countInInput(r.key1);
            int repeats = Math.max(1, jobRepeatLeft);
            int totalNeed = r.count * repeats;

            if (have >= r.count) {
                // Перед переходом к следующему типу — платим чанк по эссенции
                int chunk = Math.max(1, perTypeEssentia);
                if (tryPayEssentiaChunk(chunk)) {
                    step++; // чанк оплачен — переходим к следующему типу
                } else {
                    // Недостаточно эссенции — ждём догрузки снизу (drawEssentiaTicked) и выходим
                    return;
                }
            } else {
                int missingTotal = Math.max(0, totalNeed - have);
                if (useManagerForProvision()) {
                    needEnsureWithManager = true;
                    ensureWithManager(true);
                    return;
                }
                // Не хватает предметов — при необходимости делаем провизию (если не подавлена)
                long now = world.getTotalWorldTime();
                if (!suppressSelfProvision && (lastOrderWorldTime == 0L || now - lastOrderWorldTime >= REORDER_TICKS)) {
                    ItemStack req = normalizeForProvision(r.key1, Math.min(missingTotal, r.key1.getMaxStackSize()));
                    GolemHelper.requestProvisioning(world, pos, EnumFacing.UP, req, 0);
                    lastOrderWorldTime = now;
                    supplyCooldown = SUPPLY_COOLDOWN;
                }
                return;
            }
        }

        // --- Финальная фаза: все типы закрыты, остаётся убедиться, что долг закрыт и место под результат есть ---
        if (step >= seq.size()) {
            // Если из-за каких-то расхождений долг ещё остался — дожимаем по частям
            if (costRemaining > 0) {
                // Платим минимальными порциями, чтобы не зависать при маленьком буфере
                int chunk = Math.min(Math.max(1, perTypeEssentia), costRemaining);
                if (!tryPayEssentiaChunk(chunk)) {
                    return; // ждём догрузку эссенции
                }
            }

            // Долг погашен, входы все на месте, выход примет — выпускаем
            if (costRemaining == 0 && hasAllForGrid(grid) && canAcceptResult(preview)) {
                consumeForGrid(grid);   // снять входы
                // ВАЖНО: НЕ вызываем consumeFuel(cost) — мы уже платили частями
                pushResult(preview);    // выдать результат
                jobRepeatLeft = Math.max(0, jobRepeatLeft - 1);
                markDirty();
                pingNeighbors();
                if (jobRepeatLeft > 0) {
                    seq.clear();
                    step = 0;
                    costRemaining = 0;

                    long now = world != null ? world.getTotalWorldTime() : 0L;
                    lastOrderWorldTime = now - REORDER_TICKS;
                    supplyCooldown = 0;

                    needEnsureWithManager = useManagerForProvision();
                    if (needEnsureWithManager) {
                        lastEnsureWorldTime = now - 5L;
                    }
                    return;
                }
                finishJob();            // закончить единичный цикл
            }
        }
    }


    private void finishJob() {
        this.jobActive = false;
        this.jobPatternIndex = -1;
        this.jobRepeatLeft = 1;
        this.jobRepeatTotal = 1;
        this.seq.clear();
        this.step = 0;
        this.lastOrderWorldTime = 0;

        // сбрасываем режим «от реквестера» и подавление провизии
        this.jobViaRequester = false;
        this.suppressSelfProvision = false;
        this.needEnsureWithManager = false;
        cloudDebug("task completed");

        if (world == null) return;

        // сначала — очередь от реквестера
        if (!requesterQueue.isEmpty()) {
            tryStartNextRequesterJob();
            return;
        }

    }

    private boolean shouldPreemptForRequesterQueue() {
        if (!jobActive) return false;
        if (jobViaRequester) return false;              // requester-циклы не прерываем
        if (!useManagerForProvision()) return false;    // интересует только режим через менеджер
        return true;
    }

    private void pauseActiveJobIntoRequesterQueueTail() {
        if (!jobActive) return;
        int idx = this.jobPatternIndex;
        int repeatsLeft = Math.max(1, this.jobRepeatLeft);
        if (idx >= 0 && idx < PATTERN_SLOTS && patternIndexValid(idx)) {
            for (int i = 0; i < repeatsLeft; i++) {
                requesterQueue.addLast(idx);
            }
        }

        // Сброс только активного состояния, саму очередь не трогаем.
        this.jobActive = false;
        this.jobPatternIndex = -1;
        this.jobRepeatLeft = 1;
        this.jobRepeatTotal = 1;
        this.seq.clear();
        this.step = 0;
        this.lastOrderWorldTime = 0L;
        this.jobViaRequester = false;
        this.suppressSelfProvision = false;
        this.needEnsureWithManager = false;
    }

    private void pingNeighbors() {
        if (world == null || world.isRemote) return;
        try {
            IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, 3);
            world.notifyNeighborsOfStateChange(pos, state.getBlock(), true);
            for (EnumFacing f : EnumFacing.VALUES) {
                BlockPos np = pos.offset(f);
                world.notifyNeighborsOfStateChange(np, world.getBlockState(np).getBlock(), true);
            }
        } catch (Throwable ignored) {}
    }

    // ===== Self-provision normalize =====
    private static ItemStack normalizeForProvision(ItemStack like, int amount) {
        if (isTcCrystal(like)) {
            Aspect a = crystalAspect(like);
            if (a != null) return ThaumcraftApiHelper.makeCrystal(a, Math.max(1, amount));
        }
        ItemStack r = like.copy(); r.setCount(Math.max(1, amount)); return r;
    }



    // ===== IEssentiaTransport =====
    private static boolean canFaceInput(EnumFacing face) {
        if (face == null) return false;
        for (EnumFacing f : ESSENTIA_INPUT_FACES) if (f == face) return true;
        return false;
    }

    @Override public boolean isConnectable(EnumFacing face) { return canFaceInput(face); }
    @Override public boolean canInputFrom(EnumFacing face)  { return canFaceInput(face); }
    @Override public boolean canOutputTo(EnumFacing face)   { return false; }
    @Override public void setSuction(Aspect aspect, int amount) {}
    @Override public Aspect getSuctionType(EnumFacing face) { return (canFaceInput(face) && craftAmount < CRAFT_CAP) ? requiredAspect : null; }
    @Override public int getSuctionAmount(EnumFacing face)  { return (canFaceInput(face) && craftAmount < CRAFT_CAP) ? CRAFT_SUCTION : 0; }
    @Override public int addEssentia(Aspect aspect, int amount, EnumFacing face) {
        if (!canFaceInput(face)) return 0;
        if (aspect != requiredAspect || amount <= 0) return 0;
        int can = Math.min(amount, CRAFT_CAP - craftAmount);
        if (can <= 0) return 0;
        craftAmount += can;
        markDirty(); pingNeighbors();
        return can;
    }
    @Override public int takeEssentia(Aspect aspect, int amount, EnumFacing face) { return 0; }
    @Override public Aspect getEssentiaType(EnumFacing face) { return craftAmount > 0 ? requiredAspect : null; }
    @Override public int getEssentiaAmount(EnumFacing face)  { return craftAmount; }
    @Override public int getMinimumSuction()                 { return 8; }

    // ===== NBT / сеть =====
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        nbt.setTag(NBT_PATTERNS, patterns.serializeNBT());
        nbt.setTag(NBT_INPUT,    input.serializeNBT());
        nbt.setTag(NBT_OUTPUT,   output.serializeNBT());
        if (hasCustomName()) nbt.setString(NBT_CUSTOMNAME, customName);
        nbt.setInteger("CraftAmount", craftAmount);
        nbt.setString("ReqAspect", requiredAspect == null ? "" : requiredAspect.getTag());
        nbt.setInteger("PerTypeEssentia", perTypeEssentia);
        nbt.setInteger("CostRemaining", costRemaining);


        nbt.setBoolean("JobActive", jobActive);
        nbt.setInteger("JobPatternIndex", jobPatternIndex);
        nbt.setInteger("Step", step);
        nbt.setLong("LastOrderWT", lastOrderWorldTime);
        nbt.setInteger("JobRepeatLeft", jobRepeatLeft);
        nbt.setInteger("JobRepeatTotal", jobRepeatTotal);

        nbt.setInteger("LastSignal", lastSignal);

        net.minecraft.nbt.NBTTagList rq = new net.minecraft.nbt.NBTTagList();
        for (Integer idx : requesterQueue) {
            net.minecraft.nbt.NBTTagCompound c = new net.minecraft.nbt.NBTTagCompound();
            c.setInteger("I", idx == null ? -1 : idx);
            rq.appendTag(c);
        }
        nbt.setTag("RequesterQ", rq);

        if (managerPos != null) nbt.setLong("Manager", managerPos.toLong());
        nbt.setBoolean("ManagerPattern", managerFromPattern && managerPos != null);

        return nbt;
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        if (nbt.hasKey(NBT_PATTERNS, Constants.NBT.TAG_COMPOUND)) patterns.deserializeNBT(nbt.getCompoundTag(NBT_PATTERNS));
        if (nbt.hasKey(NBT_INPUT,    Constants.NBT.TAG_COMPOUND)) input.deserializeNBT(nbt.getCompoundTag(NBT_INPUT));
        if (nbt.hasKey(NBT_OUTPUT,   Constants.NBT.TAG_COMPOUND)) output.deserializeNBT(nbt.getCompoundTag(NBT_OUTPUT));
        if (output.getSlots() < OUTPUT_SLOTS) {
            ItemStackHandler neo = makeOutputHandler(OUTPUT_SLOTS);
            for (int i = 0; i < output.getSlots(); i++) {
                neo.setStackInSlot(i, output.getStackInSlot(i));
            }
            output = neo;
        }
        customName = nbt.hasKey(NBT_CUSTOMNAME, Constants.NBT.TAG_STRING) ? nbt.getString(NBT_CUSTOMNAME) : "";
        craftAmount = nbt.getInteger("CraftAmount");
        Aspect a = Aspect.getAspect(nbt.getString("ReqAspect"));
        if (a != null) requiredAspect = a;
        perTypeEssentia = Math.max(1, nbt.getInteger("PerTypeEssentia"));
        costRemaining = Math.max(0, nbt.getInteger("CostRemaining"));

        jobActive = nbt.getBoolean("JobActive");
        jobPatternIndex = nbt.getInteger("JobPatternIndex");
        step = Math.max(0, nbt.getInteger("Step"));
        lastOrderWorldTime = nbt.getLong("LastOrderWT");
        jobRepeatLeft = Math.max(1, nbt.getInteger("JobRepeatLeft"));
        jobRepeatTotal = Math.max(1, nbt.getInteger("JobRepeatTotal"));

        lastSignal = nbt.getInteger("LastSignal");

        requesterQueue.clear();
        if (nbt.hasKey("RequesterQ", Constants.NBT.TAG_LIST)) {
            net.minecraft.nbt.NBTTagList rq = nbt.getTagList("RequesterQ", Constants.NBT.TAG_COMPOUND);
            for (int i = 0; i < rq.tagCount(); i++) {
                net.minecraft.nbt.NBTTagCompound c = rq.getCompoundTagAt(i);
                int idx = c.getInteger("I");
                if (idx >= 0 && idx < PATTERN_SLOTS) requesterQueue.addLast(idx);
            }
        }

        managerPos = nbt.hasKey("Manager", Constants.NBT.TAG_LONG)
                ? BlockPos.fromLong(nbt.getLong("Manager")) : null;
        managerFromPattern = nbt.getBoolean("ManagerPattern") && managerPos != null;
        needEnsureWithManager = jobActive && useManagerForProvision();

        // последовательность пересоберём при первом тике работы
        seq.clear();
    }
    @Override public NBTTagCompound getUpdateTag() { return writeToNBT(new NBTTagCompound()); }
    @Override public SPacketUpdateTileEntity getUpdatePacket() { return new SPacketUpdateTileEntity(getPos(), 0, getUpdateTag()); }
    @Override public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) { readFromNBT(pkt.getNbtCompound()); }

    // ===== UI =====
    public boolean hasCustomName() { return customName != null && !customName.isEmpty(); }
    public String getName() { return hasCustomName() ? customName : "container.thaumicattempts.golem_crafter"; }
    public void setCustomName(String name) { this.customName = name == null ? "" : name; markDirty(); }
    public ITextComponent getDisplayName() { return new TextComponentTranslation(getName()); }
}
