package therealpant.thaumicattempts.common;

public class SidedProxy {
}
