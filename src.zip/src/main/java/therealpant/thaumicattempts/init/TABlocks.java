// therealpant.thaumicattempts.init.TABlocks.java
package therealpant.thaumicattempts.init;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

public class TABlocks {
    public static Block MIRROR_MANAGER;
    public static Block MIRROR_MANAGER_CORE;
    public static Block ORDER_TERMINAL;
    public static Block PATTERN_REQUESTER;
    public static Block RESOURCE_REQUESTER;
    public static Block GOLEM_DISPATCHER;
    public static Block INFUSION_REQUESTER;
    public static Block ANOMALY_STONE;
    public static Block RIFT_BUSH;
    public static Block RIFT_GEOD;
    public static Block RIFT_STONE_BASE;
    public static Block ELDRITCH_CONSTARCTION;

    public static Item MIRROR_MANAGER_ITEM;
    public static Item MIRROR_MANAGER_CORE_ITEM;
    public static Item ORDER_TERMINAL_ITEM;
    public static Item PATTERN_REQUESTER_ITEM;
    public static Item RESOURCE_REQUESTER_ITEM;
    public static Item GOLEM_DISPATCHER_ITEM;
    public static Item INFUSION_REQUESTER_ITEM;
    public static Item ANOMALY_STONE_ITEM;
    public static Item RIFT_BUSH_ITEM;
    public static Item RIFT_GEOD_ITEM;
    public static Item RIFT_STONE_BASE_ITEM;
    public static Item ELDRITCH_CONSTARCTION_ITEM;
}

