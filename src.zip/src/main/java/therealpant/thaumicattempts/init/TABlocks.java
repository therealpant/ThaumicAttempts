// therealpant.thaumicattempts.init.TABlocks.java
package therealpant.thaumicattempts.init;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

public class TABlocks {
    public static Block MIRROR_MANAGER;
    public static Block MIRROR_MANAGER_CORE;
    public static Block ORDER_TERMINAL;
    public static Block PATTERN_REQUESTER;
    public static Block RESOURCE_REQUESTER;
    public static Block GOLEM_DISPATCHER;
    public static Block INFUSION_REQUESTER;
    public static Block ANOMALY_STONE;
    public static Block RIFT_BUSH;
    public static Block RIFT_GEOD;
    public static Block RIFT_STONE_BASE;
    public static Block ELDRITCH_CONSTRUCTION;
    public static Block ANOMALY_BED;
    public static Block ANOMALY_CROP;
    public static Block AURA_BOOSTER;
    public static Block AURA_BOOSTER_CORE;
    public static Block RIST_CRISTAL_BLOCK;
    public static Block RIFT_EXTRACTOR;

    public static Item MIRROR_MANAGER_ITEM;
    public static Item MIRROR_MANAGER_CORE_ITEM;
    public static Item ORDER_TERMINAL_ITEM;
    public static Item PATTERN_REQUESTER_ITEM;
    public static Item RESOURCE_REQUESTER_ITEM;
    public static Item GOLEM_DISPATCHER_ITEM;
    public static Item INFUSION_REQUESTER_ITEM;
    public static Item ANOMALY_STONE_ITEM;
    public static Item RIFT_BUSH_ITEM;
    public static Item RIFT_GEOD_ITEM;
    public static Item RIFT_STONE_BASE_ITEM;
    public static Item ELDRITCH_CONSTRUCTION_ITEM;
    public static Item ANOMALY_BED_ITEM;
    public static Item AURA_BOOSTER_ITEM;
    public static Item AURA_BOOSTER_CORE_ITEM;
    public static Item RIST_CRISTAL_BLOCK_ITEM;
    public static Item RIFT_EXTRACTOR_ITEM;
}

