// src/main/java/therealpant/thaumicattempts/client/ClientModels.java
package therealpant.thaumicattempts.client;

import net.minecraft.block.state.IBlockState;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.StateMap;
import net.minecraft.client.renderer.block.statemap.StateMapperBase;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import therealpant.thaumicattempts.ThaumicAttempts;
import therealpant.thaumicattempts.client.render.*;
import therealpant.thaumicattempts.golemcraft.ModBlocksItems;
import therealpant.thaumicattempts.golemnet.block.BlockMathCore;
import therealpant.thaumicattempts.golemnet.block.BlockMirrorStabilizer;
import therealpant.thaumicattempts.golemnet.tile.*;

import therealpant.thaumicattempts.init.TABlocks;
import therealpant.thaumicattempts.proxy.CommonProxy;
import therealpant.thaumicattempts.tile.TilePillar;
import therealpant.thaumicattempts.world.tile.TileAnomalyStone;
import therealpant.thaumicattempts.world.tile.TileAuraBooster;
import therealpant.thaumicattempts.world.tile.TileRiftExtractor;
import therealpant.thaumicattempts.world.tile.TileRiftGeod;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = ThaumicAttempts.MODID)
public final class ClientModels extends CommonProxy {

    @SubscribeEvent
    public static void onModelRegistry(ModelRegistryEvent e) {
        /* ---------- ITEM-модели (иконки в инвентаре) ---------- */

        // простые предметы
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.CRAFT_PATTERN, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":craft_pattern", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.INFUSION_PATTERN, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":infusion_pattern", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.ARCANE_PATTERN, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":arcane_pattern", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RESOURCE_LIST, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":resource_list", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_FLOWER, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_flover", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_STONE, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_stone", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_CRISTAL, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_cristal", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_EMBER, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_ember", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_AMETIST, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_ametist", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.RIFT_BRILIANT, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":rift_briliant", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.ANOMALY_SEEDS, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":ta_anomaly_seeds", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.MIND_FRUIT, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":ta_mind_fruit", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.MATURE_MIND_FRUIT, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":ta_mature_mind_fruit", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TAINTED_MIND_FRUIT, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":ta_tainted_mind_fruit", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.MIND_POTION, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":mind_potion", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 0,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amber_1", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 1,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amber_2", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 2,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amber_3", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 3,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amethyst_1", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 4,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amethyst_2", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 5,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_amethyst_3", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 6,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_diamond_1", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 7,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_diamond_2", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                ModBlocksItems.TA_GEM, 8,
                new ModelResourceLocation(ThaumicAttempts.MODID + ":gem_diamond_3", "inventory")
        );

        // ItemBlock'и наших блоков (иконки!)
        registerItemBlockModel(ModBlocksItems.GOLEM_CRAFTER, ThaumicAttempts.MODID + ":golem_crafter");
        registerItemBlockModel(ModBlocksItems.ARCANE_CRAFTER, ThaumicAttempts.MODID + ":arcane_crafter");
        registerItemBlockModel(ModBlocksItems.MATH_CORE, ThaumicAttempts.MODID + ":math_core");
        registerItemBlockModel(ModBlocksItems.MIRROR_STABILIZER, ThaumicAttempts.MODID + ":mirror_stabilizer");
        registerItemBlockModel(TABlocks.RIFT_BUSH, ThaumicAttempts.MODID + ":rift_bush");
        registerItemBlockModel(TABlocks.ELDRITCH_CONSTRUCTION, ThaumicAttempts.MODID + ":eldritch_constarction");
        registerItemBlockModel(TABlocks.MIRROR_MANAGER_CORE, ThaumicAttempts.MODID + ":mirror_manager_core");
        registerItemBlockModel(TABlocks.RIFT_STONE_BASE, ThaumicAttempts.MODID + ":rift_stone_base");
        registerItemBlockModel(TABlocks.ANOMALY_BED, ThaumicAttempts.MODID + ":ta_anomaly_bed");
        registerItemBlockModel(TABlocks.AURA_BOOSTER_CORE, ThaumicAttempts.MODID + ":aura_booster_core");
        registerItemBlockModel(TABlocks.RIST_CRISTAL_BLOCK, ThaumicAttempts.MODID + ":rist_cristal_block");

        // ухо — используем таумовскую иконку предмета
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocksItems.EAR_BAND), 0,
                new ModelResourceLocation("thaumcraft:arcane_ear", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(TABlocks.RESOURCE_REQUESTER), 0,
                new ModelResourceLocation("thaumicattempts:resource_requester", "inventory")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(TABlocks.INFUSION_REQUESTER), 0,
                new ModelResourceLocation("thaumicattempts:infusion_requester", "inventory")
        );

        // предметы-«тайлы»
        registerItemModel(TABlocks.MIRROR_MANAGER_ITEM);
        attachTileRenderer(TABlocks.MIRROR_MANAGER_ITEM, TileMirrorManager::new);
        registerItemModel(TABlocks.MIRROR_MANAGER_CORE_ITEM);
        registerItemModel(TABlocks.RIFT_STONE_BASE_ITEM);
        registerItemModel(TABlocks.ORDER_TERMINAL_ITEM);
        registerItemModel(TABlocks.PATTERN_REQUESTER_ITEM);
        registerItemModel(TABlocks.RESOURCE_REQUESTER_ITEM);
        attachTileRenderer(TABlocks.RESOURCE_REQUESTER_ITEM, TileResourceRequester::new);
        registerItemModel(TABlocks.INFUSION_REQUESTER_ITEM);
        attachTileRenderer(TABlocks.INFUSION_REQUESTER_ITEM, TileInfusionRequester::new);
        registerItemModel(TABlocks.GOLEM_DISPATCHER_ITEM);
        attachTileRenderer(TABlocks.GOLEM_DISPATCHER_ITEM, TileGolemDispatcher::new);
        registerItemModel(TABlocks.ANOMALY_STONE_ITEM);
        attachTileRenderer(TABlocks.ANOMALY_STONE_ITEM, therealpant.thaumicattempts.world.tile.TileAnomalyStone::new);
        registerItemModel(TABlocks.RIFT_GEOD_ITEM);
        attachTileRenderer(TABlocks.RIFT_GEOD_ITEM, TileRiftGeod::new);
        registerItemModel(TABlocks.AURA_BOOSTER_ITEM);
        attachTileRenderer(TABlocks.AURA_BOOSTER_ITEM, TileAuraBooster::new);
        registerItemModel(TABlocks.RIFT_EXTRACTOR_ITEM);
        attachTileRenderer(TABlocks.RIFT_EXTRACTOR_ITEM, TileRiftExtractor::new);
        /* ---------- StateMappers (рендер БЛОКА в мире) ---------- */

        // наши крафтеры: игнорируем таумовский ENABLED (если присутствует)
        ModelLoader.setCustomStateMapper(
                ModBlocksItems.GOLEM_CRAFTER,
                new StateMap.Builder()
                        .ignore(thaumcraft.common.blocks.IBlockEnabled.ENABLED)
                        .build()
        );
        ModelLoader.setCustomStateMapper(
                ModBlocksItems.ARCANE_CRAFTER,
                new StateMap.Builder()
                        .ignore(thaumcraft.common.blocks.IBlockEnabled.ENABLED)
                        .build()
        );

        // ВАЖНО: для ядра и стабилизатора игнорируем ТОЛЬКО наше свойство ACTIVATOR.
        // Свойство active остаётся — оно выбирает модель (active=true/false).
        // СТАБИЛИЗАТОР ЗЕРКАЛ
        ModelLoader.setCustomStateMapper(
                ModBlocksItems.MIRROR_STABILIZER,
                (new StateMap.Builder()).ignore(BlockMirrorStabilizer.SIG).build()
        );

// МАТ. ЯДРО
        ModelLoader.setCustomStateMapper(
                ModBlocksItems.MATH_CORE,
                (new StateMap.Builder()).ignore(BlockMathCore.SIG).build()
        );

        // Таумовское «ухо»: у блока нет ENABLED, мапим все состояния на готовый ресурс.
        ModelLoader.setCustomStateMapper(
                ModBlocksItems.EAR_BAND,
                new StateMapperBase() {
                    @Override
                    protected ModelResourceLocation getModelResourceLocation(IBlockState state) {
                        // Thaumcraft сам разрулит варианты через свой blockstate
                        return new ModelResourceLocation("thaumcraft:arcane_ear");
                    }
                }
        );

        /* ---------- TESR ---------- */
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileMirrorManager.class,
                new RenderMirrorManagerGeo());
        ClientRegistry.bindTileEntitySpecialRenderer(
                TilePatternRequester.class,
                new RenderPatternRequesterGeo()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileResourceRequester.class,
                new RenderResourceRequester()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                    TileGolemDispatcher.class,
                    new DispatcherRenderer()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileInfusionRequester.class,
                new RenderInfusionRequester()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TilePillar.class,
                new RenderPillar()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileAnomalyStone.class,
                new RenderAnomalyStone()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileRiftGeod.class,
                new RenderRiftGeod()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileAuraBooster.class,
                new RenderAuraBoosterGeo()
        );
        ClientRegistry.bindTileEntitySpecialRenderer(
                TileRiftExtractor.class,
                new RenderRiftExtractor()
        );
    }

    private static void registerItemBlockModel(net.minecraft.block.Block block, String path) {
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(block), 0,
                new ModelResourceLocation(path, "inventory")
        );
    }

    private static void registerItemModel(Item item) {
        ModelLoader.setCustomModelResourceLocation(
                item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory")
        );
    }

    private static void attachTileRenderer(Item item, Supplier<? extends net.minecraft.tileentity.TileEntity> factory) {
        item.setTileEntityItemStackRenderer(new TileItemStackRenderer<>(factory));
    }
}
