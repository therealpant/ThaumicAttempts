package therealpant.thaumicattempts.proxy;

import net.minecraftforge.fml.common.event.*;

public class CommonProxy {
    // [Сервер/общая логика] — пока ничего не требуется
    public void preInit(FMLPreInitializationEvent e) {}
    public void init(FMLInitializationEvent e) {}
    public void postInit(FMLPostInitializationEvent e) {}


}
