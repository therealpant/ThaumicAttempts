package therealpant.thaumicattempts.world.tile;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.fml.common.Loader;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.core.PlayState;
import software.bernie.geckolib3.core.builder.AnimationBuilder;
import software.bernie.geckolib3.core.controller.AnimationController;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;
import software.bernie.geckolib3.core.manager.AnimationData;
import software.bernie.geckolib3.core.manager.AnimationFactory;
import thaumcraft.api.ThaumcraftApiHelper;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.IEssentiaTransport;
import thaumcraft.api.aura.AuraHelper;
import thecodex6824.thaumicaugmentation.api.client.ImpetusRenderingManager;
import thecodex6824.thaumicaugmentation.api.impetus.node.*;
import thecodex6824.thaumicaugmentation.api.internal.TAInternals;
import therealpant.thaumicattempts.ThaumicAttempts;
import therealpant.thaumicattempts.config.TAConfig;

import thecodex6824.thaumicaugmentation.api.impetus.node.prefab.SimpleImpetusConsumer;
import thecodex6824.thaumicaugmentation.api.util.DimensionalBlockPos;

import javax.annotation.Nullable;
import java.util.Deque;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;


public class TileAuraBooster extends TileEntity implements ITickable, IEssentiaTransport, IAnimatable {

    private final AnimationFactory factory = new AnimationFactory(this);

    private static final String TAUG_MODID = "thaumicaugmentation";
    private static final int TICK_INTERVAL = 60;
    private static final int ESSENTIA_CAP = 40;
    private static final int ESSENTIA_SUCTION = 1024;
    private static final int ESSENTIA_BASE_COST = 6;
    private static final int IMPETUS_BASE_COST = 6;
    private static final int HEAT_RESET_TICKS = 240;
    private static final int PEARL_DAMAGE_INTERVAL = 10;
    private static final float VIS_ADD_MULTIPLIER = 0.10F;
    private static final float VIS_MAX_MULTIPLIER = 0.75F;
    private static final Aspect REQUIRED_ASPECT = Aspect.AURA;
    private static final String PEARL_ID = "thaumcraft:primordial_pearl";
    private static final String NBT_IMPETUS_NODE = "TAugImpetusNode";

    private final ItemStackHandler inventory = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) {
            markDirtyAndSync();
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isPearl(stack);
        }

        @Override
        public int getSlotLimit(int slot) {
            return 1;
        }
    };

    private int tickCounter;
    private int drawDelay;
    private int suctionPingCooldown;
    private int essentiaAmount;
    private int pearlUseCounter;
    private int essentiaCostCurrent = ESSENTIA_BASE_COST;
    private int impetusCostCurrent = IMPETUS_BASE_COST;
    private long lastWorkTick;
    @Nullable
    private IImpetusConsumer impetusConsumer;
    @Nullable
    private NBTTagCompound pendingImpetusTag;

    @Override
    public void update() {
        if (world == null || world.isRemote) return;
        ensureImpetusNode();
        pullEssentiaFromNeighbors();
        if (suctionPingCooldown-- <= 0) {
            if (essentiaAmount < ESSENTIA_CAP) {
                notifyEssentiaChange();
            }
            suctionPingCooldown = 20;
        }
        if (++tickCounter % TICK_INTERVAL != 0) return;
        attemptBoost();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        ensureImpetusNode();
    }

    @Override
    public void validate() {
        super.validate();
        ensureImpetusNode();
    }

    @Override
    public void invalidate() {
        unloadImpetusNode();
        super.invalidate();
    }

    @Override
    public void onChunkUnload() {
        unloadImpetusNode();
        super.onChunkUnload();
    }

    public ItemStack getPearlStack() {
        return inventory.getStackInSlot(0);
    }

    public boolean tryInsertPearl(net.minecraft.entity.player.EntityPlayer player, EnumHand hand) {
        if (player == null || hand == null) return false;
        ItemStack held = player.getHeldItem(hand);
        if (!isPearl(held)) return false;
        if (!inventory.getStackInSlot(0).isEmpty()) return false;
        ItemStack toInsert = held.copy();
        toInsert.setCount(1);
        ItemStack remainder = inventory.insertItem(0, toInsert, false);
        if (!remainder.isEmpty()) return false;
        if (!player.capabilities.isCreativeMode) {
            held.shrink(1);
        }
        markDirtyAndSync();
        return true;
    }

    public boolean tryExtractPearl(net.minecraft.entity.player.EntityPlayer player) {
        if (player == null) return false;
        if (inventory.getStackInSlot(0).isEmpty()) return false;
        ItemStack extracted = inventory.extractItem(0, 1, false);
        if (extracted.isEmpty()) return false;
        boolean added = player.inventory.addItemStackToInventory(extracted);
        if (!added && world != null) {
            net.minecraft.inventory.InventoryHelper.spawnItemStack(world, pos.getX(), pos.getY(), pos.getZ(), extracted);
        }
        markDirtyAndSync();
        return true;
    }

    private boolean hasPearl() {
        return isPearl(getPearlStack());
    }

    private void attemptBoost() {
        long now = world.getTotalWorldTime();
        if (now - lastWorkTick >= HEAT_RESET_TICKS) {
            resetHeatCosts();
        }
        int pearlBonus = hasPearl() ? 1 : 0;
        int impetusEfficiency = Math.min(3, 2 + pearlBonus);
        long requestedImpetus = 0L;
        long consumedImpetus = 0L;
        int requestedEssentia = 0;
        int consumedEssentia = 0;
        float payRatio = 0.0F;

        if (canBoostAny(impetusEfficiency)) {
            requestedImpetus = impetusCostCurrent;
            consumedImpetus = consumeImpetus(requestedImpetus, false);
            payRatio = clamp01(requestedImpetus <= 0 ? 0.0F : (float) consumedImpetus / (float) requestedImpetus);
            if (payRatio > 0.0F) {
                debugPowerAttempt(requestedImpetus, consumedImpetus, 0, 0, payRatio);
                if (boostChunks(impetusEfficiency, payRatio)) {
                    applyHeatIncrease();
                    lastWorkTick = now;
                    handlePearlWear();
                    return;
                }
            }
        }

        int efficiency = Math.min(3, 1 + pearlBonus);
        if (!canBoostAny(efficiency)) return;
        requestedEssentia = essentiaCostCurrent;
        consumedEssentia = consumeEssentiaPartial(requestedEssentia);
        payRatio = clamp01(requestedEssentia <= 0 ? 0.0F : (float) consumedEssentia / (float) requestedEssentia);
        if (payRatio <= 0.0F) return;
        debugPowerAttempt(0L, 0L, requestedEssentia, consumedEssentia, payRatio);
        if (boostChunks(efficiency, payRatio)) {
            consumeEssentia(consumedEssentia);
            applyHeatIncrease();
            lastWorkTick = now;
            handlePearlWear();
        }
    }

    private void handlePearlWear() {
        if (!hasPearl()) return;
        pearlUseCounter++;
        if (pearlUseCounter < PEARL_DAMAGE_INTERVAL) return;
        pearlUseCounter = 0;
        ItemStack stack = inventory.getStackInSlot(0);
        if (stack.isEmpty()) return;
        if (stack.isItemStackDamageable()) {
            stack.setItemDamage(stack.getItemDamage() + 1);
            if (stack.getItemDamage() >= stack.getMaxDamage()) {
                stack.shrink(1);
            }
        } else {
            stack.shrink(1);
        }
        markDirtyAndSync();
    }

    private boolean canBoostAny(int efficiency) {
        if (efficiency <= 0) return false;
        BlockPos origin = pos;
        int chunkX = origin.getX() >> 4;
        int chunkZ = origin.getZ() >> 4;
        if (efficiency == 3) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (needsBoost(chunkX + dx, chunkZ + dz, efficiency)) {
                        return true;
                    }
                }
            }
            return false;
        }
        return needsBoost(chunkX, chunkZ, efficiency);
    }

    private boolean boostChunks(int efficiency, float payRatio) {
        if (efficiency <= 0 || payRatio <= 0.0F) return false;
        BlockPos origin = pos;
        int chunkX = origin.getX() >> 4;
        int chunkZ = origin.getZ() >> 4;
        boolean boosted = false;
        if (efficiency == 3) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    boosted |= boostChunk(chunkX + dx, chunkZ + dz, efficiency, payRatio);
                }
            }
            return boosted;
        }
        return boostChunk(chunkX, chunkZ, efficiency, payRatio);
    }

    private boolean needsBoost(int chunkX, int chunkZ, int efficiency) {
        float base = getChunkBase(chunkX, chunkZ);
        if (base <= 0.0F) return false;
        float max = base * (1.0F + VIS_MAX_MULTIPLIER * efficiency);
        float current = AuraHelper.getVis(world, getChunkCenter(chunkX, chunkZ));
        return current < 0.8F * max;
    }

    private boolean boostChunk(int chunkX, int chunkZ, int efficiency, float payRatio) {
        float base = getChunkBase(chunkX, chunkZ);
        if (base <= 0.0F) return false;
        float max = base * (1.0F + VIS_MAX_MULTIPLIER * efficiency);
        BlockPos chunkPos = getChunkCenter(chunkX, chunkZ);
        float current = AuraHelper.getVis(world, chunkPos);
        if (current >= 0.8F * max) return false;
        float add = base * VIS_ADD_MULTIPLIER * efficiency;
        float allowed = max - current;
        if (allowed <= 0.0F) return false;
        float toAdd = Math.min(add, allowed);
        if (toAdd <= 0.0F) return false;
        float scaled = toAdd * payRatio;
        if (scaled <= 0.0F) return false;
        AuraHelper.addVis(world, chunkPos, scaled);
        return true;
    }

    private float getChunkBase(int chunkX, int chunkZ) {
        BlockPos chunkCenter = getChunkCenter(chunkX, chunkZ);
        float base = AuraHelper.getAuraBase(world, chunkCenter);
        return base > 0.0F ? base : 0.0F;
    }

    private BlockPos getChunkCenter(int chunkX, int chunkZ) {
        return new BlockPos((chunkX << 4) + 8, pos.getY(), (chunkZ << 4) + 8);
    }

    private void consumeEssentia(int amount) {
        if (amount <= 0 || essentiaAmount <= 0) return;
        essentiaAmount = Math.max(0, essentiaAmount - amount);
        markDirtyAndSync();
        notifyEssentiaChange();
    }

    private int consumeEssentiaPartial(int requested) {
        if (requested <= 0 || essentiaAmount <= 0) return 0;
        return Math.min(requested, essentiaAmount);
    }

    private boolean pullEssentiaFromNeighbors() {
        if (++drawDelay % 5 != 0 || world == null || world.isRemote) return false;
        if (essentiaAmount >= ESSENTIA_CAP) return false;
        boolean pulled = false;
        for (EnumFacing inFace : EnumFacing.VALUES) {
            TileEntity te = ThaumcraftApiHelper.getConnectableTile(world, pos, inFace);
            if (!(te instanceof IEssentiaTransport)) continue;
            IEssentiaTransport transport = (IEssentiaTransport) te;
            EnumFacing opp = inFace.getOpposite();
            if (!transport.canOutputTo(opp)) continue;
            if (transport.getSuctionAmount(opp) < this.getSuctionAmount(inFace)) {
                int taken = transport.takeEssentia(REQUIRED_ASPECT, 1, opp);
                if (taken > 0) {
                    essentiaAmount = Math.min(ESSENTIA_CAP, essentiaAmount + taken);
                    pulled = true;
                    break;
                }
            }
        }
        if (pulled) {
            markDirtyAndSync();
            notifyEssentiaChange();
        }
        return pulled;
    }

    private void resetHeatCosts() {
        essentiaCostCurrent = ESSENTIA_BASE_COST;
        impetusCostCurrent = IMPETUS_BASE_COST;
    }

    private void applyHeatIncrease() {
        essentiaCostCurrent += (int) Math.ceil(ESSENTIA_BASE_COST / 3.0);
        impetusCostCurrent += (int) Math.ceil(IMPETUS_BASE_COST / 3.0);
    }

    private void debugPowerAttempt(long requestedImpetus, long consumedImpetus, int requestedEssentia,
                                   int consumedEssentia, float payRatio) {
        if (!TAConfig.ENABLE_AURA_BOOSTER_DEBUG_LOGS) return;
        ThaumicAttempts.LOGGER.debug(
                "[AuraBooster] requestedImpetus={}, consumed={}, requestedEssentia={}, consumed={}, ratio={}",
                requestedImpetus, consumedImpetus, requestedEssentia, consumedEssentia, payRatio
        );
    }

    private float clamp01(float value) {
        if (value < 0.0F) return 0.0F;
        if (value > 1.0F) return 1.0F;
        return value;
    }

    private void notifyEssentiaChange() {
        if (world != null) {
            world.notifyNeighborsOfStateChange(pos, getBlockType(), true);
        }
    }

    private static boolean isPearl(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        Item pearl = Item.getByNameOrId(PEARL_ID);
        return pearl != null && stack.getItem() == pearl;
    }

    private void markDirtyAndSync() {
        markDirty();
        if (world != null) {
            world.notifyBlockUpdate(pos, world.getBlockState(pos), world.getBlockState(pos), 3);
        }
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        if (compound.hasKey("Inventory")) {
            inventory.deserializeNBT(compound.getCompoundTag("Inventory"));
        }
        essentiaAmount = compound.getInteger("Essentia");
        pearlUseCounter = compound.getInteger("PearlUse");
        essentiaCostCurrent = compound.getInteger("HeatEssCost");
        impetusCostCurrent = compound.getInteger("HeatImpCost");
        lastWorkTick = compound.getLong("HeatLastWork");
        if (essentiaCostCurrent <= 0) essentiaCostCurrent = ESSENTIA_BASE_COST;
        if (impetusCostCurrent <= 0) impetusCostCurrent = IMPETUS_BASE_COST;
        if (compound.hasKey(NBT_IMPETUS_NODE)) {
            pendingImpetusTag = compound.getCompoundTag(NBT_IMPETUS_NODE);
            if (impetusConsumer instanceof INBTSerializable) {
                ((INBTSerializable<NBTTagCompound>) impetusConsumer).deserializeNBT(pendingImpetusTag);
                pendingImpetusTag = null;
            }
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setTag("Inventory", inventory.serializeNBT());
        compound.setInteger("Essentia", essentiaAmount);
        compound.setInteger("PearlUse", pearlUseCounter);
        compound.setInteger("HeatEssCost", essentiaCostCurrent);
        compound.setInteger("HeatImpCost", impetusCostCurrent);
        compound.setLong("HeatLastWork", lastWorkTick);
        if (impetusConsumer instanceof INBTSerializable) {
            compound.setTag(NBT_IMPETUS_NODE, ((INBTSerializable<NBTTagCompound>) impetusConsumer).serializeNBT());
        }
        return compound;
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        return writeToNBT(new NBTTagCompound());
    }

    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        return new SPacketUpdateTileEntity(pos, 0, getUpdateTag());
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readFromNBT(pkt.getNbtCompound());
    }

    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) return true;
        if (capability == CapabilityImpetusNode.IMPETUS_NODE && Loader.isModLoaded(TAUG_MODID)) return true;
        return super.hasCapability(capability, facing);
    }

    @Nullable
    @Override
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(inventory);
        }
        if (capability == CapabilityImpetusNode.IMPETUS_NODE && Loader.isModLoaded(TAUG_MODID)) {
            ensureImpetusNode();
            if (impetusConsumer != null) {
                return capability.cast((T) impetusConsumer);
            }
        }
        return super.getCapability(capability, facing);
    }

    // ========================= IEssentiaTransport =========================

    @Override
    public boolean isConnectable(EnumFacing face) {
        return true;
    }

    @Override
    public boolean canInputFrom(EnumFacing face) {
        return true;
    }

    @Override
    public boolean canOutputTo(EnumFacing face) {
        return false;
    }

    @Override
    public void setSuction(Aspect aspect, int amount) {}

    @Override
    public Aspect getSuctionType(EnumFacing face) {
        return essentiaAmount < ESSENTIA_CAP ? REQUIRED_ASPECT : null;
    }

    @Override
    public int getSuctionAmount(EnumFacing face) {
        return essentiaAmount < ESSENTIA_CAP ? ESSENTIA_SUCTION : 0;
    }

    @Override
    public int addEssentia(Aspect aspect, int amount, EnumFacing face) {
        if (aspect != REQUIRED_ASPECT || amount <= 0) return 0;
        int can = Math.min(amount, ESSENTIA_CAP - essentiaAmount);
        if (can <= 0) return 0;
        essentiaAmount += can;
        markDirtyAndSync();
        notifyEssentiaChange();
        return can;
    }

    @Override
    public int takeEssentia(Aspect aspect, int amount, EnumFacing face) {
        return 0;
    }

    @Override
    public Aspect getEssentiaType(EnumFacing face) {
        return essentiaAmount > 0 ? REQUIRED_ASPECT : null;
    }

    @Override
    public int getEssentiaAmount(EnumFacing face) {
        return essentiaAmount;
    }

    @Override
    public int getMinimumSuction() {
        return 8;
    }

    private void ensureImpetusNode() {
        if (world == null) return;
        if (!Loader.isModLoaded(TAUG_MODID)) return;

        if (impetusConsumer == null) {
            DimensionalBlockPos loc = new DimensionalBlockPos(pos, world.provider.getDimension());
            impetusConsumer = new SimpleImpetusConsumer(1, 0, loc);

            // init можно безопасно и на клиенте, и на сервере
            impetusConsumer.init(world);

            // применяем pending nbt (важно и для клиента, чтобы node имел правильные данные)
            if (pendingImpetusTag != null && impetusConsumer instanceof INBTSerializable) {
                ((INBTSerializable<NBTTagCompound>) impetusConsumer).deserializeNBT(pendingImpetusTag);
                pendingImpetusTag = null;
            }

            if (world.isRemote) {
                // ✅ ключевое: регистрируем как renderable node, чтобы strong transaction рисовался до booster
                registerRenderableNodeClient();
            } else {
                // только сервер: граф, валидация, автоконнект
                NodeHelper.validate(impetusConsumer, world);
                NodeHelper.tryConnectNewlyLoadedPeers(impetusConsumer, world);
            }
        } else {
            // на всякий: если TE переместился/после загрузки, обновим location
            if (impetusConsumer instanceof IImpetusNode) {
                ((IImpetusNode) impetusConsumer).setLocation(
                        new DimensionalBlockPos(pos, world.provider.getDimension())
                );
            }
        }
    }

    @SideOnly(Side.CLIENT)
    private void registerRenderableNodeClient() {
        if (impetusConsumer instanceof IImpetusNode) {
            ImpetusRenderingManager.registerRenderableNode((IImpetusNode) impetusConsumer);
        }
    }

    @SideOnly(Side.CLIENT)
    private void deregisterRenderableNodeClient() {
        if (impetusConsumer instanceof IImpetusNode) {
            ImpetusRenderingManager.deregisterRenderableNode((IImpetusNode) impetusConsumer);
        }
    }

    private void unloadImpetusNode() {
        if (world != null && world.isRemote) {
            deregisterRenderableNodeClient();
        }
        if (impetusConsumer != null) {
            impetusConsumer.unload();
        }
        impetusConsumer = null;
    }


    private long consumeImpetus(long requested, boolean simulate) {
        if (requested <= 0) return 0L;
        ensureImpetusNode();
        if (impetusConsumer == null) return 0L;

        ConsumeResult result = NodeHelper.consumeImpetusFromConnectedProviders(requested, impetusConsumer, simulate);
        long consumed = (result == null) ? 0L : result.energyConsumed;

        if (!simulate && consumed > 0 && result != null && result.paths != null && !result.paths.isEmpty()) {
            // ВАЖНО: сам consumer должен быть IImpetusNode
            IImpetusNode selfNode = (impetusConsumer instanceof IImpetusNode) ? (IImpetusNode) impetusConsumer : null;

            for (Map.Entry<Deque<IImpetusNode>, Long> e : result.paths.entrySet()) {
                Long amt = e.getValue();
                if (amt == null || amt <= 0) continue;

                // копируем путь, чтобы можно было дописать хвост
                List<IImpetusNode> nodes = new ArrayList<>(e.getKey());

                // ДОБАВЛЯЕМ consumer в конец, если его нет
                if (selfNode != null) {
                    if (nodes.isEmpty() || nodes.get(nodes.size() - 1) != selfNode) {
                        nodes.add(selfNode);
                    }
                }

                TAInternals.syncImpetusTransaction(nodes);
            }
        }

        return consumed;
    }


    @Override
    public void registerControllers(AnimationData data) {
        data.addAnimationController(new AnimationController<>(this, "controller", 0, this::predicate));
    }

    private <E extends IAnimatable> PlayState predicate(AnimationEvent<E> event) {
        event.getController().setAnimation(
                new AnimationBuilder().addAnimation("animation.aura_booster.idle", true)
        );
        return PlayState.CONTINUE;
    }

    @Override
    public AnimationFactory getFactory() {
        return factory;
    }
}
