package therealpant.thaumicattempts.api;

public enum FluxAnomalyTier {
    SURFACE,
    SHALLOW,
    DEEP
}