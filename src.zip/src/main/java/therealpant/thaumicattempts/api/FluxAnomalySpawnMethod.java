package therealpant.thaumicattempts.api;

/**
 * Способ появления или вызова аномалии.
 */
public enum FluxAnomalySpawnMethod {
    API,
    COMMAND,
    WORLD_GEN,
    STRUCTURE,
    SCRIPTED
}